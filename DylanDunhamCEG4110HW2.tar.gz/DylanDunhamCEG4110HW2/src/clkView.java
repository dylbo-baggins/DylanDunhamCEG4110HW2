package dunham.dylan.dylandunhamhw2ceg4110attempt2;

public interface clkView {
    public void setHour(int hour);
    public void setMin(int min);
    public void setSec(int sec);
    public void setDay(int day);
    public void setWeekDay(int weekDay);
    public void setMon(int mon);
    public void setYear(int year);
    public String getTime();
}

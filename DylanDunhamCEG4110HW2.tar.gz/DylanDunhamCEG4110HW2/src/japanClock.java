package dunham.dylan.dylandunhamhw2ceg4110attempt2;

public class japanClock implements clkView {
    private int hour;
    private int min;
    private int sec;
    private int day;
    private int weekDay;
    private int mon;
    private int year;

    public String getTime(){
        String monthString = "";
        switch(mon){
            case 1:  monthString = "Mutsuki";
                break;
            case 2:  monthString = "Kisaragi";
                break;
            case 3:  monthString = "Yayoi";
                break;
            case 4:  monthString = "Uzuki";
                break;
            case 5:  monthString = "Satsuki";
                break;
            case 6:  monthString = "Minazuki";
                break;
            case 7:  monthString = "Fumizuki";
                break;
            case 8:  monthString = "Hazukis";
                break;
            case 9:  monthString = "Nagatsuki";
                break;
            case 10: monthString = "Kannazuki";
                break;
            case 11: monthString = "Shimotsuki";
                break;
            case 12: monthString = "Shiwasu";
                break;
        }
        String weekString = "";
        switch(weekDay){
            case 1:  weekString = "nichiyōbi";
                break;
            case 2:  weekString = "getsuyōbi";
                break;
            case 3:  weekString = "kayōbi";
                break;
            case 4:  weekString = "suiyōbi";
                break;
            case 5:  weekString = "mokuyōbi";
                break;
            case 6:  weekString = "kin'yōbi";
                break;
            case 7:  weekString = "doyōbi";
                break;
        }
        String dayString = "";
        switch(day){
            case 1:  dayString = "tsuitachi";
                break;
            case 2:  dayString = "futsuka";
                break;
            case 3:  dayString = "mikka";
                break;
            case 4:  dayString = "yokka";
                break;
            case 5:  dayString = "itsuka";
                break;
            case 6:  dayString = "muika";
                break;
            case 7:  dayString = "nanoka";
                break;
            case 8:  dayString = "yōka";
                break;
            case 9:  dayString = "kokonoka";
                break;
            case 10: dayString = "tōka";
                break;
            case 11: dayString = "jūichi-nichi";
                break;
            case 12: dayString = "jūni-nichi";
                break;
            case 13: dayString = "jūsan-nichi";
                break;
            case 14: dayString = "jūyon-nichi";
                break;
            case 15: dayString = "jūgo-nichi";
                break;
            case 16: dayString = "jūroku-nichi";
                break;
            case 17: dayString = "jūshichi-nichi";
                break;
            case 18: dayString = "jūhachi-nichi";
                break;
            case 19: dayString = "jūkyū-nichi";
                break;
            case 20: dayString = "hatsuka";
                break;
            case 21: dayString = "nijūichi-nichi";
                break;
            case 22: dayString = "nijūni-nichi";
                break;
            case 23: dayString = "nijūsan-nichi";
                break;
            case 24: dayString = "nijūyokka";
                break;
            case 25: dayString = "nijūgo-nichi";
                break;
            case 26: dayString = "nijūroku-nichi";
                break;
            case 27: dayString = "nijūshichi-nichi";
                break;
            case 28: dayString = "nijūhachi-nichi";
                break;
            case 29: dayString = "nijūkyū-nichi";
                break;
            case 30: dayString = "sanjū-nichi";
                break;
            case 31: dayString = "sanjūichi-nichi";
                break;

        }
        String hourString = "";
        switch(hour) {
            case 0:
                hourString = "Hour of the Rat";
                break;
            case 1:
                hourString = "Hour of the Rat";
                break;
            case 2:
                hourString = "Hour of the Ox";
                break;
            case 3:
                hourString = "Hour of the Ox";
                break;
            case 4:
                hourString = "Hour of the Tiger";
                break;
            case 5:
                hourString = "Hour of the Hare";
                break;
            case 6:
                hourString = "Hour of the Hare";
                break;
            case 7:
                hourString = "Hour of the Dragon";
                break;
            case 8:
                hourString = "Hour of the Dragon";
                break;
            case 9:
                hourString = "Hour of the Snake";
                break;
            case 10:
                hourString = "Hour of the Snake";
                break;
            case 11:
                hourString = "Hour of the Horse";
                break;
            case 12:
                hourString = "Hour of the Horse";
                break;
            case 13:
                hourString = "Hour of the Sheep";
                break;
            case 14:
                hourString = "Hour of the Sheep";
                break;
            case 15:
                hourString = "Hour of the Monkey";
                break;
            case 16:
                hourString = "Hour of the Monkey";
                break;
            case 17:
                hourString = "Hour of the Monkey";
                break;
            case 18:
                hourString = "Hour of the Rooster";
                break;
            case 19:
                hourString = "Hour of the Rooster";
                break;
            case 20:
                hourString = "Hour of the Dog";
                break;
            case 21:
                hourString = "Hour of the Dog";
                break;
            case 22:
                hourString = "Hour of the Boar";
                break;
            case 23:
                hourString = "Hour of the Boar";
                break;
        }
        return weekString + ", " + dayString + ", " + monthString + ", " + (year+660) + ". " + hourString + ":" + min + " pun, " + sec + " byou.";
    }

    @Override
    public void setHour(int hour) {
        this.hour = hour;
    }

    @Override
    public void setMin(int min) {
        this.min = min;
    }

    @Override
    public void setSec(int sec) {
        this.sec = sec;
    }

    @Override
    public void setDay(int day) {
        this.day = day;
    }

    @Override
    public void setWeekDay(int weekDay) {
        this.weekDay = weekDay;
    }

    @Override
    public void setMon(int mon) {
        this.mon = mon;
    }

    @Override
    public void setYear(int year) {
        this.year = year;
    }
}

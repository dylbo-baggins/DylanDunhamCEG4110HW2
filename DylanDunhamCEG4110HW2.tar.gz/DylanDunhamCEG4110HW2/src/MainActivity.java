package dunham.dylan.dylandunhamhw2ceg4110attempt2;

import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AnalogClock;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {
    private GridView gv;
    private Button btn;
    private clockCtr ctr;
    private ClockModel model;
    private static clkCmd cmd;
    private Timer timer;
    private mTimeTask tick;
    private ArrayAdapter<String> gridViewArrayAdapter;
    private Spinner hour;
    private Spinner min;
    private Spinner sec;
    private Spinner weekday;
    private Spinner day;
    private Spinner mon;
    private Spinner year;
    private ArrayAdapter<CharSequence> hourAdapt;
    private ArrayAdapter<CharSequence> minAdapt;
    private ArrayAdapter<CharSequence> secAdapt;
    private ArrayAdapter<CharSequence> weekdayAdapt;
    private ArrayAdapter<CharSequence> dayAdapt;
    private ArrayAdapter<CharSequence> monAdapt;
    private ArrayAdapter<CharSequence> yearAdapt;
    private List<String> viewStrings = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        gv = (GridView) findViewById(R.id.gv);
        btn = (Button) findViewById(R.id.btn);
        ctr = new clockCtr();
        model = new ClockModel(ctr);
        ctr.registerModel(model);
        // Create a new ArrayAdapter
        gridViewArrayAdapter = new ArrayAdapter<String>
                (this,android.R.layout.simple_list_item_1, viewStrings);

        // Data bind GridView with ArrayAdapter (String Array elements)
        gv.setAdapter(gridViewArrayAdapter);
        hour = (Spinner) findViewById(R.id.hour);
        hourAdapt = ArrayAdapter.createFromResource(this, R.array.hours, android.R.layout.simple_spinner_item);
        hourAdapt.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        hour.setAdapter(hourAdapt);
        hour.setSelection(model.getHour());

        min = (Spinner) findViewById(R.id.min);
        minAdapt = ArrayAdapter.createFromResource(this, R.array.minssecs, android.R.layout.simple_spinner_item);
        minAdapt.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        min.setAdapter(minAdapt);
        min.setSelection(model.getMin()-1);

        sec = (Spinner) findViewById(R.id.sec);
        secAdapt = ArrayAdapter.createFromResource(this, R.array.minssecs, android.R.layout.simple_spinner_item);
        secAdapt.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sec.setAdapter(secAdapt);
        sec.setSelection(model.getSec()-1);

        weekday = (Spinner) findViewById(R.id.weekday);
        weekdayAdapt = ArrayAdapter.createFromResource(this, R.array.weekdays, android.R.layout.simple_spinner_item);
        weekdayAdapt.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        weekday.setAdapter(weekdayAdapt);
        weekday.setSelection(model.getWeekDay()-1);

        day = (Spinner) findViewById(R.id.day);
        dayAdapt = ArrayAdapter.createFromResource(this, R.array.days, android.R.layout.simple_spinner_item);
        dayAdapt.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        day.setAdapter(dayAdapt);
        day.setSelection(model.getDay()-1);

        mon = (Spinner) findViewById(R.id.mon);
        monAdapt = ArrayAdapter.createFromResource(this, R.array.mons, android.R.layout.simple_spinner_item);
        monAdapt.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mon.setAdapter(monAdapt);
        mon.setSelection(model.getMon()-1);

        year = (Spinner) findViewById(R.id.year);
        yearAdapt = ArrayAdapter.createFromResource(this, R.array.years, android.R.layout.simple_spinner_item);
        yearAdapt.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        year.setAdapter(yearAdapt);
        year.setSelection(model.getYear()-1900);

        cmd = clkCmd.getInst();
        cmd.registerCtr(ctr);

        hour.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                cmd.doIt(sec.getSelectedItemPosition()+1,min.getSelectedItemPosition()+1,(position),weekday.getSelectedItemPosition()+1,day.getSelectedItemPosition()+1,mon.getSelectedItemPosition()+1, Integer.parseInt((String) year.getSelectedItem()));
                gridViewArrayAdapter.notifyDataSetChanged();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        min.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                cmd.doIt(sec.getSelectedItemPosition()+1,(position+1), hour.getSelectedItemPosition(),weekday.getSelectedItemPosition()+1,day.getSelectedItemPosition()+1,mon.getSelectedItemPosition()+1,Integer.parseInt((String) year.getSelectedItem()));
                gridViewArrayAdapter.notifyDataSetChanged();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        sec.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                cmd.doIt((position+1), min.getSelectedItemPosition()+1, hour.getSelectedItemPosition(),weekday.getSelectedItemPosition()+1,day.getSelectedItemPosition()+1,mon.getSelectedItemPosition()+1,Integer.parseInt((String) year.getSelectedItem()));
                gridViewArrayAdapter.notifyDataSetChanged();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        weekday.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                cmd.doIt(sec.getSelectedItemPosition()+1, min.getSelectedItemPosition()+1, hour.getSelectedItemPosition(),(position+1), day.getSelectedItemPosition()+1,mon.getSelectedItemPosition()+1,Integer.parseInt((String) year.getSelectedItem()));
                gridViewArrayAdapter.notifyDataSetChanged();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        day.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                cmd.doIt(sec.getSelectedItemPosition()+1, min.getSelectedItemPosition()+1, hour.getSelectedItemPosition(),weekday.getSelectedItemPosition()+1, (position+1),mon.getSelectedItemPosition()+1,Integer.parseInt((String) year.getSelectedItem()));
                gridViewArrayAdapter.notifyDataSetChanged();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        mon.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                cmd.doIt(sec.getSelectedItemPosition()+1, min.getSelectedItemPosition()+1, hour.getSelectedItemPosition(),weekday.getSelectedItemPosition()+1, day.getSelectedItemPosition()+1,(position+1),Integer.parseInt((String) year.getSelectedItem()));
                gridViewArrayAdapter.notifyDataSetChanged();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        year.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                cmd.doIt(sec.getSelectedItemPosition()+1, min.getSelectedItemPosition()+1, hour.getSelectedItemPosition(),weekday.getSelectedItemPosition()+1, day.getSelectedItemPosition()+1,mon.getSelectedItemPosition()+1, Integer.parseInt((String) year.getSelectedItem()));
                gridViewArrayAdapter.notifyDataSetChanged();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        timer = new Timer();
        tick = new mTimeTask();
        timer.schedule(tick, 0, 1000);
    }
    public void addEngClk(View view){
        engClock ec = new engClock();
        ctr.addView(ec);
        ctr.updateViews();
        viewStrings.add(ctr.getLastClockString());
        gridViewArrayAdapter.notifyDataSetChanged();

    }
    public void addJapanClk(View view){
        japanClock jc = new japanClock();
        ctr.addView(jc);
        ctr.updateViews();
        viewStrings.add(ctr.getLastClockString());
        gridViewArrayAdapter.notifyDataSetChanged();

    }
    public void undo(View view){
        cmd.undoIt();
        gridViewArrayAdapter.notifyDataSetChanged();
    }
    public void redo(View view){
        cmd.redoIt();
        gridViewArrayAdapter.notifyDataSetChanged();
    }
    public Handler mHandler = new Handler() {
        public void handleMessage(Message msg) {
            gridViewArrayAdapter.notifyDataSetChanged();
        }
    };
    class mTimeTask extends TimerTask {

        @Override
        public void run(){
            ctr.tickModel();

            ctr.updateViews();


            for(int i =0; i<viewStrings.size(); i++){
                viewStrings.set(i, ctr.getViewAsStrings(i));
            }
            mHandler.obtainMessage(1).sendToTarget();
        }
    }
}

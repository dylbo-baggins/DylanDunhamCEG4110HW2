package dunham.dylan.dylandunhamhw2ceg4110attempt2;

public class clkCmd {
    private clkStack commandsDone;
    private clkStack commandsUndone;
    private clockCtr ctr;
    private static clkCmd inst = new clkCmd();
    private clkCmd(){
    }
    public static clkCmd getInst(){
        return inst;
    }
    public void registerCtr(clockCtr c){
        ctr = c;
    }
    public void doIt(int sec, int min, int hour, int weekday, int day, int mon, int year){
        if(commandsDone == null){
            commandsDone = new clkStack();
        }
        if(commandsUndone==null){
            commandsUndone = new clkStack();
        }
        int[] pushOn = {sec, min, hour, weekday, day, mon, year};
        ctr.updateModel(sec, min, hour, weekday, day, mon, year);
        ctr.updateViews();
        if(commandsDone.getSize()>0){
            int[] update = commandsDone.peek();
            if(pushOn[0] != update[0] || pushOn[1] != update[1] || pushOn[2] != update[2] || pushOn[3] != update[3] || pushOn[4] != update[4] || pushOn[5] != update[5] || pushOn[6] != update[6]){
                commandsDone.push(pushOn);
            }
        }else{
            commandsDone.push(pushOn);
        }



    }
    public void undoIt(){
        if(commandsDone == null){
            commandsDone = new clkStack();
        }
        if(commandsUndone==null){
            commandsUndone = new clkStack();
        }
        if(commandsDone.getSize()>1){
            int[] pushOn = commandsDone.pop();
            int[] update = commandsDone.peek();
            ctr.updateModel(update[0], update[1], update[2], update[3], update[4], update[5], update[6]);
            ctr.updateViews();
            commandsUndone.push(pushOn);
        }

    }
    public void redoIt(){
        if(commandsDone == null){
            commandsDone = new clkStack();
        }
        if(commandsUndone==null){
            commandsUndone = new clkStack();
        }
        if(commandsUndone.getSize()>0){
            int[] pushOn = commandsUndone.pop();
            //int[] update = commandsUndone.peek();
            ctr.updateModel(pushOn[0], pushOn[1], pushOn[2], pushOn[3], pushOn[4], pushOn[5], pushOn[6]);
            ctr.updateViews();
            commandsDone.push(pushOn);
        }

    }
}

package dunham.dylan.dylandunhamhw2ceg4110attempt2;

import android.support.v4.app.Fragment;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class clockCtr {
    private ClockModel model;
    private List<clkView> views = new ArrayList<>();
    private List<String> viewStrings = new ArrayList<>();
    public clockCtr(){

    }
    public void registerModel(ClockModel m){
        model = m;
    }
    public void updateViews(){
        for(int i =0; i<views.size(); i++){
            views.get(i).setDay(model.getDay());
            views.get(i).setWeekDay(model.getWeekDay());
            views.get(i).setMon(model.getMon());
            views.get(i).setYear(model.getYear());
            views.get(i).setHour(model.getHour());
            views.get(i).setMin(model.getMin());
            views.get(i).setSec(model.getSec());
            viewStrings.set(i, views.get(i).getTime());

        }
    }
    public void updateModel(int sec, int min, int hour, int weekday, int day, int mon, int year){
        model.setSec(sec);
        model.setMin(min);
        model.setHour(hour);
        model.setWeekDay(weekday);
        model.setDay(day);
        model.setMon(mon);
        model.setYear(year);
    }
    public void addView(clkView view){
        views.add(view);
        viewStrings.add(views.get(views.size()-1).getTime());
    }
    public String getViewAsStrings(int i){
        return viewStrings.get(i);
    }
    public List getViewStrings(){
        return viewStrings;
    }
    public void tickModel(){
        model.setSec(model.getSec() +1);
    }
    public String getLastClockString(){
        return views.get(views.size()-1).getTime();
    }

}

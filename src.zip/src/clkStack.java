package dunham.dylan.dylandunhamhw2ceg4110attempt2;

import java.util.ArrayList;

public class clkStack {
    private ArrayList<int[]> stack = new ArrayList<>();
    public clkStack(){

    }
    public void push(int[] thing){
        stack.add(thing);
    }
    public int[] pop(){
        int[] returnThing = stack.get(stack.size()-1);
        stack.remove(stack.size()-1);
        return returnThing;
    }
    public int[] peek(){
        return stack.get(stack.size()-1);
    }
    public int getSize(){
        return stack.size();
    }
}

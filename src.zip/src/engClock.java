package dunham.dylan.dylandunhamhw2ceg4110attempt2;

public class engClock implements clkView {
    private int hour;
    private int min;
    private int sec;
    private int day;
    private int weekDay;
    private int mon;
    private int year;

    public String getTime(){
        String monthString = "";
        switch(mon){
            case 1:  monthString = "January";
                break;
            case 2:  monthString = "February";
                break;
            case 3:  monthString = "March";
                break;
            case 4:  monthString = "April";
                break;
            case 5:  monthString = "May";
                break;
            case 6:  monthString = "June";
                break;
            case 7:  monthString = "July";
                break;
            case 8:  monthString = "August";
                break;
            case 9:  monthString = "September";
                break;
            case 10: monthString = "October";
                break;
            case 11: monthString = "November";
                break;
            case 12: monthString = "December";
                break;
        }
        String weekString = "";
        switch(weekDay){
            case 1:  weekString = "Sunday";
                break;
            case 2:  weekString = "Monday";
                break;
            case 3:  weekString = "Tuesday";
                break;
            case 4:  weekString = "Wednesday";
                break;
            case 5:  weekString = "Thursday";
                break;
            case 6:  weekString = "Friday";
                break;
            case 7:  weekString = "Saturday";
                break;
        }
        return weekString + ", " + day + ", " + monthString + ", " + year + ". " + hour + ":" + min + ":" + sec;
    }

    @Override
    public void setHour(int hour) {
        this.hour = hour;
    }

    @Override
    public void setMin(int min) {
        this.min = min;
    }

    @Override
    public void setSec(int sec) {
        this.sec = sec;
    }

    @Override
    public void setDay(int day) {
        this.day = day;
    }

    @Override
    public void setWeekDay(int weekDay) {
        this.weekDay = weekDay;
    }

    @Override
    public void setMon(int mon) {
        this.mon = mon;
    }

    @Override
    public void setYear(int year) {
        this.year = year;
    }
}

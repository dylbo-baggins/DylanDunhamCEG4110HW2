package dunham.dylan.dylandunhamhw2ceg4110attempt2;

import java.util.Calendar;

public class ClockModel {
    private int hour;
    private int min;
    private int sec;
    private int day;
    private int weekDay;
    private int mon;
    private int year;
    private clockCtr ctr;


    public ClockModel(clockCtr c){
        ctr = c;
        Calendar cal =  Calendar.getInstance();
        hour = cal.get(Calendar.HOUR_OF_DAY);
        min = cal.get(Calendar.MINUTE);
        sec = cal.get(Calendar.SECOND);
        day = cal.get(Calendar.DAY_OF_MONTH);
        weekDay = cal.get(Calendar.DAY_OF_WEEK);
        mon = cal.get(Calendar.MONTH);
        year = cal.get(Calendar.YEAR);


    }





    public int getHour() {
        return hour;
    }

    public void setHour(int hour) {
        this.hour = hour;
    }

    public int getMin() {
        return min;
    }

    public void setMin(int min) {
        this.min = min;
    }

    public int getSec() {
        return sec;
    }

    public void setSec(int sec) {
        this.sec = sec;
        if(this.sec ==60){
            this.sec = 0;
            min = min+1;
            if(min == 60){
                min = 0;
                hour = hour +1;
                if(hour ==25 ){
                    hour = 1;
                    weekDay = weekDay +1;
                    if(weekDay == 8){
                        weekDay =1;
                    }
                    day =day+1;
                    if(day == 32){
                        day =1;
                        mon = mon +1;
                        if(mon==13){
                            mon =1;
                            year = year+1;
                        }
                    }
                }
            }
        }

    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public int getWeekDay() {
        return weekDay;
    }

    public void setWeekDay(int weekDay) {
        this.weekDay = weekDay;
    }

    public int getMon() {
        return mon;
    }

    public void setMon(int mon) {
        this.mon = mon;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }
}
